f = int(input("Digite a temperatura em graus Farenheit:"))
c = (5 * (f - 32) / 9)
print("Celsius:", c)
print("Farenheit:", f)